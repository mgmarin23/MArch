package dte.mgmprojects.march;


import android.support.v7.app.AppCompatActivity;
//import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Switch;
//import com.google.android.material.snackbar.Snackbar;


import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.DisconnectedBufferOptions;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;

import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    Spinner Mean_sensor, Historical;
    Switch W_aut;
    Button bPublish;
    Number[] MeanS = {1, 6, 12, 24};
    //Number[] Hist= {1,6,12,24};

    int Mean, Historic;
    ExecutorService es;

    MqttAndroidClient Greenhouse;
    MqttAndroidClient mqttAndroidClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bPublish = findViewById(R.id.bPublish);
        Mean_sensor = findViewById(R.id.sp_mean);
        Historical = findViewById(R.id.sp_hist);
        W_aut = findViewById(R.id.sw_waut);

        // Adapter to adapt the data from array to Spinner
        ArrayAdapter adapter = new ArrayAdapter(MainActivity.this,
                android.R.layout.simple_spinner_item, MeanS);
        Mean_sensor.setAdapter(adapter);

        ArrayAdapter adapter2 = new ArrayAdapter(MainActivity.this,
                android.R.layout.simple_spinner_item, MeanS);
        Historical.setAdapter(adapter2);

        /*
        mqttAndroidClient = new MqttAndroidClient(getApplicationContext(),"localhost" , "AndroidClient");
        //"tcp://test.mosquitto.org:1883"
        // Establecer opciones de conexión
        MqttConnectOptions options = new MqttConnectOptions();
        options.setAutomaticReconnect(true);
        options.setCleanSession(false);
        try {            // Conectar al servidor MQTT
            IMqttToken token = mqttAndroidClient.connect(options);
            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) { // Conectado correctamente, suscribirse al tópico 'mario'
                subscribeToTopic("mario");
                Snackbar.make(findViewById(R.id.bPublish), "Client connected and subscribed", 2000).show();// Inform the user

                }
                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    // Error al conectar
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }
    private void subscribeToTopic(String topic) {
        try {            // Suscribirse al tópico especificado
            mqttAndroidClient.subscribe(topic, 0);
        } catch (MqttException e) {
            e.printStackTrace();
        }
        //}}
*/

        // Creation of the MQTT Client and subscription to the topics
        Greenhouse = new MQTTClient(this);
        Random random = new Random();
        Greenhouse.clientId = Greenhouse.clientId + random.nextInt(100000);
        Greenhouse.mqttAndroidClient = new MqttAndroidClient(getApplicationContext(), Greenhouse.serverUri, Greenhouse.clientId);
        MqttConnectOptions mqttConnectOptions = new MqttConnectOptions();
        mqttConnectOptions.setAutomaticReconnect(true);
        mqttConnectOptions.setCleanSession(false);

        //Last Will message
        mqttConnectOptions.setWill(Greenhouse.publishTopic, Greenhouse.LWillmessage.getBytes(), 0, false);

        try { //Create and connect the MQTT client. Also, create the subscriptions.

            Greenhouse.mqttAndroidClient.connect(mqttConnectOptions, null, new IMqttActionListener() {

            //IMqttToken token = Greenhouse.mqttAndroidClient.connect(mqttConnectOptions);
            // token.setActionCallback(new IMqttActionListener() {

                @Override
                public void onSuccess(IMqttToken asyncActionToken) {

                    DisconnectedBufferOptions disconnectedBufferOptions = new DisconnectedBufferOptions();
                    disconnectedBufferOptions.setBufferEnabled(true);
                    disconnectedBufferOptions.setBufferSize(100);
                    disconnectedBufferOptions.setPersistBuffer(false);
                    disconnectedBufferOptions.setDeleteOldestMessages(false);
                    Greenhouse.mqttAndroidClient.setBufferOpts(disconnectedBufferOptions);

                    Greenhouse.subscriptionTopic = "topic/#";
                    Greenhouse.subscribeToTopic();

                    Snackbar.make(findViewById(R.id.bPublish), "Client connected and subscribed", 2000).show();// Inform the user

                }
                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                }
            });

        } catch (MqttException e) {
            e.printStackTrace();
        }

        es = Executors.newSingleThreadExecutor();
        MQTTSub task = new MQTTSub(handler, Greenhouse);
        es.execute(task);

    }

    Handler handler = new Handler(Looper.getMainLooper()) { //Handler for the message received from the background. Depending on the key (topic), the message will be assigned to a specif String variable
        @Override                                   //Then, the attributes (Temperature, Humidity and Light) of each item are updated.
        public void handleMessage(Message inputMessage) {
            //this.obtainMessage();
            //Snackbar.make(findViewById(R.id.bPublish), "Client connected and subscribed", 2000).show();// Inform the user

            //Mean = inputMessage.getData().getIntegerArrayList("Tomato/Light");
            //TomatoTemperature = inputMessage.getData().getString("Tomato/Temperature");
            //TomatoHumidity = inputMessage.getData().getString("Tomato/Humidity");



        }


    };


    }
}